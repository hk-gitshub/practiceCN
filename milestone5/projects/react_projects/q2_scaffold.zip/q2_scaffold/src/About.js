import React from "react";

class About extends React.Component{
    render(){
        return(
            <div className="about">
                Hi, my name is pranav.  I am a full stack developer  and i have developed several projects with MERN stack. I am also familiar witj python and Django.
            </div>
        );
    }
}
export default About;