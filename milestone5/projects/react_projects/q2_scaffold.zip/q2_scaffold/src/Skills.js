import React from "react";

export default class Skills extends React.Component{
    render(){
        return(
                <ul className="skills">
                    <li>HTML</li>
                    <li>CSS</li>
                    <li>JavaScript</li>
                    <li>React</li>
                    <li>Node</li>
                    
                </ul>
        );
    };
}