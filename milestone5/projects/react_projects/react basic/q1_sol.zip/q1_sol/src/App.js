import "./App.css";

function App() {
  return (
    <div className="App">
      <p>
      Welcome to React Course on codingninjas.com
      </p>
    </div>
  );
}

export default App;
